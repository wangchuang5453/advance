// 入口 出口，可以配置式的
module.exports = {
  entry: './index.js',
  output: {
    filename: 'bundle.js'
  }
}