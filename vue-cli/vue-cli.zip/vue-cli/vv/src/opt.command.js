import { optmize } from './optmize';

(async () => {
  await optmize()
})()