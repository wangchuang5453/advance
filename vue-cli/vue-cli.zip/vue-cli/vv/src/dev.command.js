import { dev } from './dev';

dev().catch(console.error);